'use client'

import React from 'react'
import App from './App'

export default function DemoPage() {
  return <App />
}