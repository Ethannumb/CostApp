/**
 * Calculator Page - Database-integrated version with Payload CMS backend
 */

import PaintingCostCalculatorIntegrated from '../../../components/PaintingCostCalculatorIntegrated';

export default function CalculatorPage() {
  return <PaintingCostCalculatorIntegrated />;
}