import { test, expect, Page } from "@playwright/test";

test("default coverage rates are applied in calculation", async ({ page }: { page: Page }) => {
  // TODO
});

test("contractor CSV import updates coverage rates", async ({ page }: { page: Page }) => {
  // TODO
});

test("manual price override updates UI and report", async ({ page }: { page: Page }) => {
  // TODO
});
