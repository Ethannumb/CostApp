import { describe, it } from "vitest";

describe("Wall Duplication", () => {
  it("should duplicate a wall with same attributes", () => {
    // TODO
  });

  it("should duplicate doors and windows of a wall", () => {
    // TODO
  });
});
