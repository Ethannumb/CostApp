import { describe, it } from "vitest";

describe("Data Sources", () => {
  it("should load defaults from CSV/JSON", () => {
    // TODO
  });

  it("should apply contractor-imported data as overrides", () => {
    // TODO
  });

  it("should mark manually entered values with source=manual", () => {
    // TODO
  });
});
