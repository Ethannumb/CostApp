import { describe, it } from "vitest";

describe("Doors and Windows per Wall", () => {
  it("should allow adding 1 door", () => {
    // TODO
  });

  it("should allow adding 2 doors", () => {
    // TODO
  });

  it("should reject adding more than 2 doors", () => {
    // TODO
  });

  it("should allow adding up to 3 windows", () => {
    // TODO
  });

  it("should reject adding more than 3 windows", () => {
    // TODO
  });
});
